How to launch:

1. Install JDK 7.0 (Must be 7.0);
2. Install Maven 3.x;
3. Set environment variables: PATH, CLASSPATH, JAVA_HOME;
4. Run start.cmd.
5. Open a browser like Chrome, Firefox;
6. Navigate: http://localhost:8080/
