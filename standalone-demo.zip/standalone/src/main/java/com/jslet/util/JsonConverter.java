package com.jslet.util;

import java.lang.reflect.Type;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;

public final class JsonConverter {

	private static GsonBuilder builder = new GsonBuilder();

	public static Gson gson;
	
	static{
		builder.registerTypeAdapter(Date.class, new DateTimeConvert());
		gson = builder.create();
	}
}

class DateTimeConvert implements com.google.gson.JsonSerializer<Date>, com.google.gson.JsonDeserializer<Date>{

	public JsonElement serialize(Date arg0, Type arg1,
			JsonSerializationContext arg2) {
		Calendar calendar = Calendar.getInstance();
		calendar.clear();
		calendar.setTime(arg0);
		StringBuffer sb = new StringBuffer();
		sb.append(calendar.get(Calendar.YEAR));
		sb.append("-");
		this.appendZero(sb, calendar.get(Calendar.MONTH));
		sb.append("-");
		this.appendZero(sb, calendar.get(Calendar.DAY_OF_MONTH));
		
		sb.append("T");
		this.appendZero(sb, calendar.get(Calendar.HOUR_OF_DAY));
		sb.append(":");
		this.appendZero(sb, calendar.get(Calendar.MINUTE));
		sb.append(":");
		this.appendZero(sb, calendar.get(Calendar.SECOND));
		sb.append("Z");
	
		
		return new JsonPrimitive(sb.toString());
	}

	private void appendZero(StringBuffer sb, int value){
		if(value < 10)
			sb.append("0");
		
		sb.append(value);
	}
	
	public Date deserialize(JsonElement arg0, Type arg1,
			JsonDeserializationContext arg2) throws JsonParseException {
		String strDate = arg0.getAsString();
		Pattern p = Pattern.compile("(\\d{4})-(\\d{2})-(\\d{2})T(\\d{2}):(\\d{2}):(\\d{2})\\.(\\d{3})Z");
		Matcher m = p.matcher(strDate);
		if(m.matches()){
			MatchResult r = m.toMatchResult();
			
			Calendar calendar = Calendar.getInstance();
			calendar.clear();
			calendar.set(Integer.parseInt(r.group(1)), Integer.parseInt(r.group(2)), 
					Integer.parseInt(r.group(3)), Integer.parseInt(r.group(4)),
					Integer.parseInt(r.group(5)), Integer.parseInt(r.group(6)));
			
			return calendar.getTime();
		}
		return null;
	}
	
	
}
