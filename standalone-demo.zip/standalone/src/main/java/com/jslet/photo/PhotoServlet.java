package com.jslet.photo;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PhotoServlet
 */
public class PhotoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public PhotoServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		String x = this.getServletContext().getRealPath("/zh-cn/demo/photo/1.jpg");
//		response.getOutputStream().print(x);
//		response.getOutputStream().flush();
//		return;
		String id = request.getParameter("id");
		if(id == null) {
			return;
		}
		InputStream is = this.getServletContext().getResourceAsStream("/photo/" + id.trim() + ".jpg");
		if(is == null) {
			return;
		}
		response.setContentType("image/jpeg");
		try {
			byte[] buf = new byte[1024];
			int bytesRead;
			while ((bytesRead = is.read(buf)) != -1)
				response.getOutputStream().write(buf, 0, bytesRead);
		} finally {
			is.close();
			response.getOutputStream().flush();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
