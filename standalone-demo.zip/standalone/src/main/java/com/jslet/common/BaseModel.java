package com.jslet.common;
/**
 * <pre>
 * 
 *  Accela Automation
 *  File: BaseModel.java
 * 
 *  Accela, Inc.
 *  Copyright (C): 2013
 * 
 *  Description:
 *  TODO
 * 
 *  Notes:
 * 	$Id: BaseModel.java 72642 2009-01-01 20:01:57Z ACHIEVO\tony.tong $ 
 * 
 *  Revision History
 *  &lt;Date&gt;,			&lt;Who&gt;,			&lt;What&gt;
 *  Oct 16, 2013		tony.tong		Initial.
 *  
 * </pre>
 */
public class BaseModel
{
	private String chgflag;

	/**
	 * @return the chgflag
	 */
	
	public final String getChgflag()
	{
		return chgflag;
	}

	/**
	 * @param chgflag the chgflag to set
	 */
	public final void setChgflag(String chgflag)
	{
		this.chgflag = chgflag;
	}
}

/*
*$Log: av-env.bat,v $
*/