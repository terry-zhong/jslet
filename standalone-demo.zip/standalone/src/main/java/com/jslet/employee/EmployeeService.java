package com.jslet.employee;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.lang.reflect.Type;

import com.google.gson.reflect.*;
import com.jslet.util.JsonConverter;

public class EmployeeService {

	public static List<Employee> InitialEmployees = new ArrayList<Employee>();

	public static List<Employee> AllEmployees = new ArrayList<Employee>();

	public static List<Department> AllDepts = new ArrayList<Department>();
	
	private static Type listType = new TypeToken<List<Employee>>() {
	}.getType();

//	private static Timer timer = new Timer();

	static {
		initEmployee();
		initDept();
		restoreData();
//		timer.schedule(new RestoreTask(), 1000, 1000 * 3600 * 2);
	}

	public String findAll() {
		// PersonDAO dao = new PersonDAO();
		// List<Person> list = dao.findAll();
		// AllPersons.clear();
		return JsonConverter.gson.toJson(AllEmployees);
	}

	public String save(String chgJson) {
		List<Employee> persons = JsonConverter.gson.fromJson(chgJson, listType);
		String flag;
		Employee oldEmp;
		for(Employee emp: persons) {
			flag = emp.getChgflag();
			if(flag.startsWith("i")) {
				AllEmployees.add(emp);
			} else if(flag.startsWith("u")) {
				oldEmp = this.findById(emp.getWorkerid());
				if (oldEmp != null) {
					oldEmp.copy(emp);
				}
			} else {
				oldEmp = this.findById(emp.getWorkerid());
				if (oldEmp != null)
					AllEmployees.remove(oldEmp);			
			}
		}
		return chgJson;
	}

	public String findEmployeeAndDept() {
		String depts = JsonConverter.gson.toJson(AllDepts);
		String result = "{\"department\":" + depts + ",\"result\":" + this.findAll() + "}";
		return result;
	}

	private Employee findById(int id) {
		for (Employee p : AllEmployees) {
			if (id == p.getWorkerid())
				return p;
		}
		return null;
	}

	public static void restoreData() {
		AllEmployees.clear();
		Employee p;
		for (Iterator<Employee> ir = InitialEmployees.iterator(); ir.hasNext();) {
			p = new Employee();
			p.copy(ir.next());
			AllEmployees.add(p);
		}
	}

	private static void initEmployee() {
		Calendar calendar = Calendar.getInstance();

		Employee p = new Employee();
		p.setWorkerid(1);
		p.setName("Tom");
		p.setAge(19);
		p.setGender("1");
		calendar.clear();
		calendar.set(1992, 3, 12);
		p.setBirthday(calendar.getTime());
		p.setMarried(true);
		p.setDepartment("00");
		p.setPhoto("1.jpg");
		p.setPosition("3");

		InitialEmployees.add(p);

		p = new Employee();
		p.setWorkerid(2);
		p.setName("Jerry");
		p.setAge(20);
		p.setGender("0");
		calendar.clear();
		calendar.set(1991, 5, 12);
		p.setBirthday(calendar.getTime());
		p.setMarried(true);
		p.setDepartment("01");
		p.setPhoto("2.jpg");
		p.setPosition("3");
		InitialEmployees.add(p);

		p = new Employee();
		p.setWorkerid(3);
		p.setName("John");
		p.setAge(34);
		p.setGender("1");
		calendar.clear();
		calendar.set(1977, 2, 14);
		p.setBirthday(calendar.getTime());
		p.setMarried(true);
		p.setDepartment("01");
		p.setPhoto("3.jpg");
		p.setProvince("02");
		p.setPosition("1");
		InitialEmployees.add(p);

		p = new Employee();
		p.setWorkerid(4);
		p.setName("Tony");
		p.setAge(37);
		p.setGender("1");
		calendar.clear();
		calendar.set(1974, 1, 6);
		p.setBirthday(calendar.getTime());
		p.setMarried(true);
		p.setDepartment("00");
		p.setProvince("05");
		p.setPosition("0");
		p.setPhoto("4.jpg");
		InitialEmployees.add(p);
	}

	private static void initDept() {
		Department dpt = new Department();
		dpt.setDeptid("00");
		dpt.setName("Dept 0.");
		dpt.setAddress("shenzhen");
		AllDepts.add(dpt);
		
		dpt = new Department();
		dpt.setDeptid("01");
		dpt.setName("Dept 1.");
		dpt.setAddress("beijin");
		AllDepts.add(dpt);
		
		dpt = new Department();
		dpt.setDeptid("0101");
		dpt.setName("Dept 11.");
		dpt.setAddress("chengdu");
		dpt.setParentid("01");
		AllDepts.add(dpt);
		
		dpt = new Department();
		dpt.setDeptid("0102");
		dpt.setName("Dept 12.");
		dpt.setAddress("shanghai");
		dpt.setParentid("01");
		AllDepts.add(dpt);
		
		dpt = new Department();
		dpt.setDeptid("02");
		dpt.setName("Dept 2.");
		dpt.setAddress("shenzhen");
		AllDepts.add(dpt);
		
		dpt = new Department();
		dpt.setDeptid("0201");
		dpt.setName("Dept 21.");
		dpt.setAddress("shenzhen");
		dpt.setParentid("02");
		AllDepts.add(dpt);
		
		dpt = new Department();
		dpt.setDeptid("0202");
		dpt.setName("Dept 22.");
		dpt.setAddress("shanghai");
		dpt.setParentid("02");
		AllDepts.add(dpt);
		
		dpt = new Department();
		dpt.setDeptid("03");
		dpt.setName("Dept 3.");
		dpt.setAddress("beijin");
		AllDepts.add(dpt);
		
		dpt = new Department();
		dpt.setDeptid("04");
		dpt.setName("Dept 4.");
		dpt.setAddress("beijin");
		AllDepts.add(dpt);	
	}
}

class RestoreTask extends java.util.TimerTask {

	@Override
	public void run() {
		EmployeeService.restoreData();
	}
}