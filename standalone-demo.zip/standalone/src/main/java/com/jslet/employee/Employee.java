package com.jslet.employee;

import java.io.Serializable;
import java.util.Date;

import com.jslet.common.BaseModel;

public class Employee extends BaseModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1577625979761129266L;

	private int workerid;
	
	private String name;
	
	private String department;
	
	private String gender;
	
	private int age;
	
	private boolean married;
	
	private Date birthday;
	
	private String position;
	
	private double salary;
	
	private String university;
	
	private String province;
	
	private String city;

	private String photo;
	
	public int getWorkerid() {
		return workerid;
	}

	public void setWorkerid(int workerid) {
		this.workerid = workerid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public boolean isMarried() {
		return married;
	}

	public void setMarried(boolean married) {
		this.married = married;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getUniversity() {
		return university;
	}

	public void setUniversity(String university) {
		this.university = university;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public void copy(Employee p){
		if(p == null)
			return;
		this.workerid = p.getWorkerid();
		this.name = p.getName();
		this.department = p.getDepartment();
		this.gender = p.getGender();
		this.age = p.getAge();
		this.married = p.isMarried();
		this.birthday = p.getBirthday();
		this.position = p.getPosition();
		this.salary = p.getSalary();
		this.university = p.getUniversity();
		this.province = p.getProvince();
		this.city = p.getCity();
		this.photo = p.getPhoto();
	}
	
}
