package com.jslet.bom;

import java.util.ArrayList;
import java.util.List;

import com.jslet.util.JsonConverter;

public class BomService {

	public static List<Bom> AllBom = new ArrayList<Bom>();

	static {
		for (int i = 0; i < 2000; i++) {
			AllBom.add(new Bom("B" + i, i + 1000));
		}
	}

	public String findBom(int pageNum, int pageSize) {
		List<Bom> list;
		int pageCount = 1;
		if(pageNum == 0 ||pageSize == 0)
			list = AllBom;
		else{
			list = new ArrayList<Bom>();
			int start = (pageNum - 1)*pageSize;
			int end = pageNum * pageSize;
			for(int i = start; i < end; i++){
				list.add(AllBom.get(i));
			}
			Double p = Math.ceil(AllBom.size() / pageSize);
			pageCount = p.intValue();
		}
		String dataStr = JsonConverter.gson.toJson(list);
		return "{\"pageCount\":" + pageCount + ",\"result\":" + dataStr + "}";
	}
}
