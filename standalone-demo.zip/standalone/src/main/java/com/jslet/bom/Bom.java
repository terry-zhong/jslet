package com.jslet.bom;

import java.io.Serializable;

public class Bom implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6097290494833326096L;

	private String itemid;
	
	private int stdnum;

	public Bom(String itemid, int stdnum){
		this.itemid = itemid;
		this.stdnum = stdnum;
	}
	
	public String getItemid() {
		return itemid;
	}

	public void setItemid(String itemid) {
		this.itemid = itemid;
	}

	public int getStdnum() {
		return stdnum;
	}

	public void setStdnum(int stdnum) {
		this.stdnum = stdnum;
	}
	
	
	
	
	
}
