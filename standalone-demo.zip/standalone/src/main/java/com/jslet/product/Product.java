package com.jslet.product;

import java.io.Serializable;
import java.util.Date;

import com.jslet.common.BaseModel;

public class Product extends BaseModel implements Serializable {

	private static final long serialVersionUID = -1577625979761129265L;

	private String product;
	
	private int quantity;
	
	private double price;
	
	private String state;
	
	private String auditor;
	
	private Date auditdate;

	public final String getProduct()
	{
		return product;
	}

	public final void setProduct(String product)
	{
		this.product = product;
	}

	public final int getQuantity()
	{
		return quantity;
	}

	public final void setQuantity(int quantity)
	{
		this.quantity = quantity;
	}

	public final double getPrice()
	{
		return price;
	}

	public final void setPrice(double price)
	{
		this.price = price;
	}

	public final String getState()
	{
		return state;
	}

	public final void setState(String state)
	{
		this.state = state;
	}

	public final String getAuditor()
	{
		return auditor;
	}

	public final void setAuditor(String auditor)
	{
		this.auditor = auditor;
	}

	public final Date getAuditdate()
	{
		return auditdate;
	}

	public final void setAuditdate(Date auditdate)
	{
		this.auditdate = auditdate;
	}
}
