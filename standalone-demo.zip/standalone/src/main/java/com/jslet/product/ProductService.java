package com.jslet.product;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.lang.reflect.Type;

import com.google.gson.reflect.*;
import com.jslet.util.JsonConverter;

public class ProductService {

	public static List<Product> AllProducts = new ArrayList<Product>();

	private final static String INITIALSTATE = "Initial";
	
	private static Type listType = new TypeToken<List<Product>>() {
	}.getType();

	static {
		initProduct();
	}

	public String findAll() {
		return JsonConverter.gson.toJson(AllProducts);
	}

	public String audit(String chgJson) {
		List<Product> products = JsonConverter.gson.fromJson(chgJson, listType);
		Product oldProduct;
		String state, auditor;
		Date auditDate = new Date();
		int k;
		for(Product product: products) {
			oldProduct = this.findByName(product.getProduct());
			state = product.getState();
			if(INITIALSTATE.equalsIgnoreCase(state)) {
				k = 0;
			} else {
				k = Integer.parseInt(state.substring(1)) + 1;
			}
			if(k < 20) {
				state = "A" + k;
				auditor = "User" + k;
			} else {
				state = INITIALSTATE;
				auditor = "Join";
			}
			oldProduct.setState(state);
			oldProduct.setAuditor(auditor);
			oldProduct.setAuditdate(auditDate);
			
			product.setState(state);
			product.setAuditor(auditor);
			product.setAuditdate(auditDate);
		}
		return JsonConverter.gson.toJson(products);
	}

	private Product findByName(String productName) {
		for(Product product: AllProducts) {
			if(product.getProduct().equalsIgnoreCase(productName)) {
				return product;
			}
		}
		return null;
	}
	
	private static void initProduct() {
		Calendar calendar = Calendar.getInstance();

		Product p = new Product();
		p.setProduct("Car");
		p.setPrice(10000.0);
		p.setQuantity(2);
		p.setState("Initial");
		p.setAuditor("Join");
		calendar.clear();
		calendar.set(2013, 3, 12);
		p.setAuditdate(calendar.getTime());
		AllProducts.add(p);

		p = new Product();
		p.setProduct("Computor");
		p.setPrice(5000.0);
		p.setQuantity(3);
		p.setState("Initial");
		p.setAuditor("Join");
		calendar.clear();
		calendar.set(2013, 5, 12);
		p.setAuditdate(calendar.getTime());
		AllProducts.add(p);

		p = new Product();
		p.setProduct("Pen");
		p.setPrice(3.0);
		p.setQuantity(300);
		p.setState("Initial");
		p.setAuditor("Join");
		p.setAuditdate(new Date());
		AllProducts.add(p);

		p = new Product();
		p.setProduct("Desk");
		p.setPrice(235.0);
		p.setQuantity(10);
		p.setState("Initial");
		p.setAuditor("Join");
		p.setAuditdate(new Date());
		AllProducts.add(p);

		p = new Product();
		p.setProduct("Book");
		p.setPrice(8.0);
		p.setQuantity(12);
		p.setState("Initial");
		p.setAuditor("Join");
		p.setAuditdate(new Date());
		AllProducts.add(p);

	}

}
